package com.anz.Hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity(name="user_details")
public class UserDetails {

	/*public UserDetails(int id, String userName) {
		super();
		this.id = id;
		this.userName = userName;
	}*/
	
	private int id;
	private String userName;
	@Id
	@Column(name="user_id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name="user_name")
	public String getUserName() {
		return userName+"_getter";
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
}
