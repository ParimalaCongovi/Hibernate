package com.anz.Hibernate.Test;



import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.anz.Hibernate.Address;
import com.anz.Hibernate.FourWheeler;
import com.anz.Hibernate.TwoWheeler;
import com.anz.Hibernate.UserDetails;
import com.anz.Hibernate.Vehicle;

public class HibernateTester {

	public static void main(String[] args) {
		
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		
		Session session= sessionFactory.openSession();
		session.beginTransaction();
		
		Query query= session.createQuery("from UserDetails");
		List<UserDetails> users=(List <UserDetails>)query.list();
		users.forEach(System.out::println);
		
		query= session.createQuery("select userName from UserDetails");
		query.setFirstResult(5);
		query.setMaxResults(4);
		List <String> userNames = (List<String>)query.list();
		userNames.forEach(System.out::println);
		
		query= session.createQuery("select count(userName) from UserDetails where userName like 'Us%'");
		System.out.println(query.list());
		
		session.getTransaction().commit();
		session.close();
		
	}

}
