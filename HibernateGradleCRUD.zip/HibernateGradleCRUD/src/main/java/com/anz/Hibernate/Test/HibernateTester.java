package com.anz.Hibernate.Test;



import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.anz.Hibernate.Address;
import com.anz.Hibernate.FourWheeler;
import com.anz.Hibernate.TwoWheeler;
import com.anz.Hibernate.UserDetails;
import com.anz.Hibernate.Vehicle;

public class HibernateTester {

	public static void main(String[] args) {
		
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		
		Session session= sessionFactory.openSession();
		session.beginTransaction();
		
		/*//Creating Records
		for(int i=1; i<=10; i++)
		{
			UserDetails user = new UserDetails();
			user.setUserName("User "+i);
			session.save(user);
		}*/
		
		//Retrieving User 7
		UserDetails user = (UserDetails) session.get(UserDetails.class, 7);
		System.out.println("Retrieved user is "+user.getUserName());
		
		//Updating User 7
		user.setUserName("Updated User");
		session.update(user);
		System.out.println("Updated user is "+user.getUserName());
		
		//Deleting User 8
		user=(UserDetails) session.get(UserDetails.class, 8);
		session.delete(user);
		
		session.getTransaction().commit();
		session.close();
		
	}

}
