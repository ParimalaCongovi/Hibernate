package com.anz.Hibernate.Test;



import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.anz.Hibernate.Address;
import com.anz.Hibernate.UserDetails;

public class HibernateTester {

	public static void main(String[] args) {
		UserDetails user=new UserDetails();

		user.setUserName("Parimala Congovi");
		Address homeaddress=new Address();
		Address officeaddress=new Address();
		homeaddress.setStreet("Selaiyur");
		homeaddress.setCity("Chennai");
		homeaddress.setState("Tamil Nadu");
		homeaddress.setPincode("600073");
		
		officeaddress.setStreet("Bellandur");
		officeaddress.setCity("Bengaluru");
		officeaddress.setState("Karnataka");
		officeaddress.setPincode("560066");
		
		user.getListOfAddresses().add(homeaddress);
		user.getListOfAddresses().add(officeaddress);
		
		
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session= sessionFactory.openSession();
		session.beginTransaction();
		session.save(user);
		session.getTransaction().commit();
		session.close();
		
		user=null;
		
		session=sessionFactory.openSession();
		session.beginTransaction();
		user=(UserDetails) session.get(UserDetails.class,1);
		System.out.println("User id is "+user.getId());
		session.getTransaction().commit();
		session.close();

	}

}
