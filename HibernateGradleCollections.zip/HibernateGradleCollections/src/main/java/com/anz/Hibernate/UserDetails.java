package com.anz.Hibernate;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.CollectionId;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;
@Entity
//Creates a table with name user_details and entity name userdetails
@Table(name="user_details")
public class UserDetails {

	/*public UserDetails(int id, String userName) {
		super();
		this.id = id;
		this.userName = userName;
	}*/
	@Id @GeneratedValue(strategy = GenerationType.TABLE)
	private int id;
	private String userName;
	
	//Treats the collection as a separate table and adds the records into the separate table. The records are referenced by the foreign key which is the user id in this case.
	@ElementCollection
	@JoinTable(name="user_address", joinColumns=@JoinColumn(name="user_id"))
	@GenericGenerator(name = "mygen", strategy ="sequence")
	@CollectionId(columns = @Column(name="address_id"),generator = "mygen",type = @Type(type = "long"))
	private Collection <Address> listOfAddresses = new ArrayList();
	
	public Collection<Address> getListOfAddresses() {
		return listOfAddresses;
	}
	public void setListOfAddresses(Collection<Address> listOfAddresses) {
		this.listOfAddresses = listOfAddresses;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
}
