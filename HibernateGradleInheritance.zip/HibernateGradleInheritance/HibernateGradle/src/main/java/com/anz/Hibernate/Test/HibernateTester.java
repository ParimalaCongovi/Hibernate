package com.anz.Hibernate.Test;



import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.anz.Hibernate.Address;
import com.anz.Hibernate.FourWheeler;
import com.anz.Hibernate.TwoWheeler;
import com.anz.Hibernate.UserDetails;
import com.anz.Hibernate.Vehicle;

public class HibernateTester {

	public static void main(String[] args) {
		
		Vehicle vehicle= new Vehicle();
		vehicle.setVehicleName("Truck");
		
		TwoWheeler Bike = new TwoWheeler();
		Bike.setVehicleName("Royal Enfield");
		Bike.setSteeringHandle("Bike's Steering Handle");
		
		FourWheeler car = new FourWheeler();
		car.setVehicleName("BMW");
		car.setSteeringWheel("Car's Steering Wheel");
		
		
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session= sessionFactory.openSession();
		session.save(vehicle);
		session.save(car);
		session.save(Bike);
		session.beginTransaction();
		session.getTransaction().commit();
		session.close();
		
	}

}
