package com.anz.Hibernate.Test;



import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.anz.Hibernate.UserDetails;

public class HibernateTester {

	public static void main(String[] args) {
		UserDetails user=new UserDetails();
		user.setId(1);
		user.setUserName("Parimala Congovi");
		user.setAddress("India");
		user.setJoinedDate(new Date());
		user.setDescription("User description");
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		Session session= sessionFactory.openSession();
		session.beginTransaction();
		session.save(user);
		session.getTransaction().commit();

	}

}
