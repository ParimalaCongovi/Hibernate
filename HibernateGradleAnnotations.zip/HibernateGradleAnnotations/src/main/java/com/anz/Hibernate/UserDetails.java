package com.anz.Hibernate;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
@Entity()
//Creates a table with name user_details and entity name userdetails
@Table(name="user_details")
public class UserDetails {

	/*public UserDetails(int id, String userName) {
		super();
		this.id = id;
		this.userName = userName;
	}*/
	@Id
	private int id;
	
	//Ignores the field userName and doesn't persist in the database.
	@Transient
	private String userName;
	
	//Creates sequel date with date field alone
	@Temporal(TemporalType.DATE)
	private Date joinedDate;
	public Date getJoinedDate() {
		return joinedDate;
	}
	public void setJoinedDate(Date joinedDate) {
		this.joinedDate = joinedDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	//Used when you need to create a datatype with characters exceeding 255 characters.
	@Lob
	private String description;
	private String address;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserName() {
		return userName+"_getter";
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
}
