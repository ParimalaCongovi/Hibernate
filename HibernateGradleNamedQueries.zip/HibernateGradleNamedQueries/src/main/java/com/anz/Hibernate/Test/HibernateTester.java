package com.anz.Hibernate.Test;



import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.anz.Hibernate.Address;
import com.anz.Hibernate.FourWheeler;
import com.anz.Hibernate.TwoWheeler;
import com.anz.Hibernate.UserDetails;
import com.anz.Hibernate.Vehicle;

public class HibernateTester {

	public static void main(String[] args) {
		
		SessionFactory sessionFactory=new Configuration().configure().buildSessionFactory();
		
		Session session= sessionFactory.openSession();
		session.beginTransaction();
		
		Query query= session.createQuery("from UserDetails");
		List<UserDetails> users=(List <UserDetails>)query.list();
		users.forEach(System.out::println);
		
		String minUserId="6", userName="User 9";
		query= session.createQuery("select userName from UserDetails where id > :userId and userName = :userName");
		query.setInteger("userId",Integer.parseInt(minUserId));
		query.setString("userName", userName);
		List <String> userNames = (List<String>)query.list();
		userNames.forEach(System.out::println);
		
		query= session.createQuery("select count(userName) from UserDetails where userName like 'Us%'");
		System.out.println(query.list());
		
		query=session.getNamedQuery("UserDetails.byId");
		query.setInteger("userId", 1);
		//@SuppressWarnings("unchecked")
		List<UserDetails> userrsId=(List <UserDetails>)query.list();
		userrsId.forEach(System.out::println);
		
		query=session.getNamedNativeQuery("UserDetails.byName");
		List<UserDetails> usersName=(List <UserDetails>)query.list();
		usersName.forEach(System.out::println);
		
		
		
		session.getTransaction().commit();
		session.close();
		
	}

}
